const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
//const salaryRoutes = require("./routes/salary");
const mainRoutes = require('./routes/main-routes');
const mongoose = require('mongoose');
const productModel = require("./models/productModel");
const { resourceLimits } = require("worker_threads");
const userRoute = require('./routes/userRoutes')
const mongodb = require('mongodb');

const app = express();

app.set("view engine", "ejs");
app.set("views", "views");

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname,'public')));
app.use (mainRoutes);
app.use( '/add',mainRoutes);
app.use( '/viewproduct',mainRoutes);

//User Managment System

app.use('/',userRoute);
 




app.use((req, res,next) => {
    res.render("404", {
        pageTitle: "Error Page Not Found",
        next
    })
});

app.get("/list",async(req,res)=>{
    let data= await productModel.find();
    res.send(data);


})







mongoose.connect('mongodb://cmdlhrltx03:27017/ShahrukhDB').then(() => {
    app.listen(3005, () => {
        console.log("Listening on port 3004");
    })
})

// app.listen(3004,()=>{
//     console.log('Started listening at port 3004')
// })