const mongoose = require('mongoose');
const { type } = require('os');
const { stringify } = require('querystring');

const userSchema = new mongoose.Schema({

    firstName:{
        type:String,
        required:true
    },
    lastName:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true
    },
    mobile:{
        type:String,
        required:true
    },
    password:{
        type:String,
        required:true
    },
    is_admin:{
        typre:Number,
      //  required:true
    },

    is_verified:{
        type:Number,
        default:0
    }




})

module.export = mongoose.model('User',userSchema);