const mongoose = require ("mongoose");
const productSchema = mongoose.Schema;

const products = new productSchema({
  _id: {
    type: productSchema.Types.ObjectId,
    required: false
},
ProductName: {
      type: String,
      required: true
    },
    Price: {
      type: Number,
      required: true
    },
    category: {
      type: String,
      required: true
    },
    description:{
      type : String,
      required:true
    }
  });
  module.exports= mongoose.model("productModel", products);