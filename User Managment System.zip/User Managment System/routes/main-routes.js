const express = require('express');

const router = express.Router();
const productController = require("../controllers/productController")

router.get('/',(req,res,next) =>{
res.render('index',{
    pageTitle: 'My Store'
});
});
router.get('/add',productController.getaddProduct);
router.post('/add',productController.postaddProduct);

 

    router.get('/viewproduct', productController.getProduct);
    
    router.post('/viewproduct', productController.postProduct);


 

   
module.exports = router;