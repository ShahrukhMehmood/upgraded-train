

const productModel = require("../models/productModel");
const mongoose = require ("mongoose");
const mongodb = require('mongodb');

const products = [];




exports.getaddProduct =((req,res,next)=>{

    res.render("add-product", {
        pageTitle:'Add Product',
        path: '/routes/main-routes.js/add',

    });
})

exports.postaddProduct = ((req, res, next) => {
    const products = new productModel({
        _id: mongoose.Types.ObjectId(),
        ProductName:req.body.ProductName,
        Price:req.body.Price,
        category:req.body.category,
        description:req.body.description,
    });
    products.save().then(addedProduct =>{
        res.redirect('/viewproduct');
    });
});

  


  
  exports.postProduct= (req,res) =>{
    const products = new productModel({
        _id: mongoose.Types.ObjectId(),
        ProductName:req.body.ProductName,
        Price:req.body.Price,
        category:req.body.category,
        description:req.body.description,
    });
    products.save().then(addedProduct =>{
        res.redirect('/viewproduct');
    });




    }

  

exports.getProduct = (req,res) =>{

  
    productModel.find().then (products=> {
        res.render("product-list", {
            pageTitle: "Product List",
            products : products
         });
     }).catch ((err)=> {
         console.log("The error is: "+err)
    });
}






