
const express = require('express');

//const router = express.Router();
//const productController = require("../controllers/productController")
const router = express.Router();
const userController = require("../controllers/userController")




router.get('/signup',userController.loadRegister);

// router.get('/',(req,res,next) =>{
// res.render('index',{
//     pageTitle: 'My Store'
// });
// });

// router.get('/signup',(req,res,next) =>{
//     res.render('signup',{
//         pageTitle: 'My Store'
//     });
//     });

module.exports = router;