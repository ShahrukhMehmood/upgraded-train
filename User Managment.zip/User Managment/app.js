const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const mongoose = require('mongoose');

const userRoutes = require('./routes/userRoute');


const app = express();

app.use(bodyParser.urlencoded({extended: false}));

app.set('view engine', 'ejs');
app.set('views', 'views');

const publicDirPath = path.join(__dirname, 'public');

app.use(express.static(publicDirPath));

//app.use('/',userRoutes);
app.use('/signup',userRoutes);






// Set 404 View here
app.use((req, res) => {
    //const isAuthenticated = req.session.isAuthenticated ? req.session.isAuthenticated : false;
    res.render('404', {
        pageTitle: 'Page not found',
       // isAuthenticated: isAuthenticated
    })
});




// mongoose.connect('mongodb://cmdlhrltx03:27017/ShahrukhDB').then(() => {
//     app.listen(3006, () => {
//         console.log(`Started listening at port 3006`);
//     });
// })


app.listen(3006, () => {
    console.log(`Started listening at port 3006`);
});
