const productFilter = {
    title: '',
    price: ''
};

module.exports = productFilter;