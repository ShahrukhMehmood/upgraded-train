const product = {
    title: '',
    description: '',
    price: 0,
    imageUrl: ''
};

module.exports = product;